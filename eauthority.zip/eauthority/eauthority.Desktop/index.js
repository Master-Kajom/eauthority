$(function() {
    var startupView = "About";
    DevExpress.devices.current("desktop");

    eauthority.app = new DevExpress.framework.html.HtmlApplication({
        namespace: eauthority,
        layoutSet: DevExpress.framework.html.layoutSets[eauthority.config.layoutSet],
        animationSet: DevExpress.framework.html.animationSets[eauthority.config.animationSet],
        mode: "webSite",
        navigation: eauthority.config.navigation,
        commandMapping: eauthority.config.commandMapping,
        navigateToRootViewMode: "keepHistory",
        useViewTitleAsBackText: true
    });

    eauthority.app.on("viewShown", function(args) {
        document.title = ko.unwrap(args.viewInfo.model.title) || "eauthority";
    });

    $(window).unload(function() {
        eauthority.app.saveState();
    });

    eauthority.app.router.register(":view/:id", { view: startupView, id: undefined });
    eauthority.app.navigate();
});