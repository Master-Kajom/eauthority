// NOTE object below must be a valid JSON
window.eauthority = $.extend(true, window.eauthority, {
    "config": {
        "layoutSet": "slideout",
        "animationSet": "default",
        "navigation": [
            {
                "title": "About",
                "onExecute": "#About",
                "icon": "info"
            }
        ]
    }
});
