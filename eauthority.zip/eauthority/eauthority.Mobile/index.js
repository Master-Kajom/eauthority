$(function() {
    var startupView = "home";

    // Uncomment the line below to disable platform-specific look and feel and to use the Generic theme for all devices
    // DevExpress.devices.current({ platform: "generic" });

    if(DevExpress.devices.real().platform === "win") {
        $("body").css("background-color", "#000");
    }

    $(document).on("deviceready", function () {
        navigator.splashscreen.hide();
        if (window.devextremeaddon) {
            window.devextremeaddon.setup();
        }
        $(document).on("backbutton", function () {
            DevExpress.processHardwareBackButton();
        });
    });

    function onNavigatingBack(e) {
        if(e.isHardwareButton && !eauthority.app.canBack()) {
            e.cancel = true;
            exitApp();
        }
    }

    function exitApp() {
        switch (DevExpress.devices.real().platform) {
            case "android":
                navigator.app.exitApp();
                break;
            case "win":
                window.external.Notify("DevExpress.ExitApp");
                break;
        }
    }

    eauthority.app = new DevExpress.framework.html.HtmlApplication({
        namespace: eauthority,
        layoutSet: DevExpress.framework.html.layoutSets[eauthority.config.layoutSet],
        animationSet: DevExpress.framework.html.animationSets[eauthority.config.animationSet],
        navigation: eauthority.config.navigation,
        commandMapping: eauthority.config.commandMapping,
        navigateToRootViewMode: "keepHistory",
        useViewTitleAsBackText: true
    });

    $(window).unload(function() {
        eauthority.app.saveState();
    });

    eauthority.app.router.register(":view/:id", { view: startupView, id: undefined });
    eauthority.app.on("navigatingBack", onNavigatingBack);
    eauthority.app.navigate();
});