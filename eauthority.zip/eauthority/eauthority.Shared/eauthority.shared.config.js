// NOTE object below must be a valid JSON
window.eauthority = $.extend(true, window.eauthority, {
    "config": {
        "endpoints": {
            "db": {
                "local": "",
                "production": ""
            }
        },
        "services": {
            "db": {
                "entities": {
                }
            }
        }
    }
});
