﻿eauthority.home = function (params) {
    "use strict";

    var dSource = [{ ID: "28609683", Name: "Kevin Gachomo Wachira" }, { ID: "28609683", Name: "Kevin Gachomo Wachira" }, { ID: "28609683", Name: "Kevin Gachomo Wachira" }];

    var commands = [{ Name: "Accepted" }, { Name: "Rejected" }, { Name: "Returned" }];

    var status = [{ ID: "1", Name: "Accepted" }, { ID: "2", Name: "Rejected" }, { ID: "3", Name: "Returned" }];
    var functionBtn = function (status_name) {

        alert(status_name);
        //console.log(e);

    }
    var viewModel = {
        viewShown: function () {
            

            //display the buttons dynamically
            /*for (var i = 0; i < status.length; i++) {
                var status_name = status[i].Name
                $("<div />").appendTo('#createbuttons').dxButton({
                    //icon: 'info',
                    text: status_name,
                    onClick: function (btn) {
                        functionBtn(status_name)
                    }
                }).appendTo('#createbuttons');

            }*/

        },
        //  Put the binding properties here
        dSource: ko.observableArray(dSource),
        commands: ko.observableArray(commands),
        name: ko.observable(),
        id: ko.observable(),
        minDate: new Date(2000, 0, 1),
        maxDate: new Date(2029, 11, 31),
        currentValue: ko.observable(new Date()),
        imgSrcs: ko.observable([""]),
        display: function () {

        },
        status_title: ko.observable(),
        buttonclicked: function (e) {
            console.log(e.itemData.Name);
            viewModel.pop_status(true);
            viewModel.status_title(e.itemData.Name);
        },
        pop_status: ko.observable(false),
        hide_status: function () {
            viewModel.pop_status(false);
        }

    };

    return viewModel;
};